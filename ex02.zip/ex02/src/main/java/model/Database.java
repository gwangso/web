package model;

import java.sql.*; //MySQL이든 뭐든 java.sql

public class Database {
	public static Connection CON;
	static {
		try {
            Class.forName("com.mysql.jdbc.Driver");
            CON=DriverManager.getConnection(
            		"jdbc:mysql://localhost:3306/webdb", "web", "pass");
            System.out.println("접속성공");
	            System.out.println("접속성공");
		} catch (Exception e) {
			System.out.println("DB 연결 실패" + e.toString());
		}
	}
}